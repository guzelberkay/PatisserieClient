﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiShop.DtoLayer.CargoDtos.CargoCompanyDtos
{
    public class CreateCargoCompanyDto
    {
        public string cargoCompanyName { get; set; }
    }
}
