﻿namespace MultiShop.DtoLayer.CatalogDtos.FeatureDtos
{
    public class CreateFeatureDto
    {
        public string Title { get; set; }
        public string Icon { get; set; }
    }
}
