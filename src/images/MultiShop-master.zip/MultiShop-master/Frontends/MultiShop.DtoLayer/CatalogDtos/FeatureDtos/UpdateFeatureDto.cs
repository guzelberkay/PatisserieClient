﻿namespace MultiShop.DtoLayer.CatalogDtos.FeatureDtos
{
    public class UpdateFeatureDto
    {
        public string FeatureId { get; set; }
        public string Title { get; set; }
        public string Icon { get; set; }
    }
}
