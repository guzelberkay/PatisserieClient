﻿namespace MultiShop.WebUI.Services.Interfaces
{
    public interface ILoginService
    {
        public string GetUserId { get; }
    }
}
