﻿namespace MultiShop.WebUI.Services.StatisticServices.UserStatisticServices
{
    public interface IUserStatisticService
    {
        Task<int> GetUsercount();
    }
}
